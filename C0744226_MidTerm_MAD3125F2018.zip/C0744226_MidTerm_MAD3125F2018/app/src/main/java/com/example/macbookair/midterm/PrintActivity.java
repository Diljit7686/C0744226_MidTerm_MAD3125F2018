package com.example.macbookair.midterm;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class PrintActivity extends AppCompatActivity {

TextView t1,t2,t3,t4,t5,t10;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_print);


        getSupportActionBar().setHomeButtonEnabled(true);

        t1 = findViewById(R.id.text1);
        t2 = findViewById(R.id.text2);
        t3 = findViewById(R.id.text3);
        t4 = findViewById(R.id.text4);
        t5 = findViewById(R.id.text5);
        t10 = findViewById(R.id.text10);


        Bundle bn = getIntent().getExtras();
        String name = bn.getString("imonthUsage");
        String name2 = bn.getString("ioffPeak");
        String name3 = bn.getString("imidPeak");
        String name4 = bn.getString("ionPeak");
        String name5 = bn.getString("ipending");
        String name10 = bn.getString("showTotal");

        t1.setText(String.valueOf(name));
        t2.setText(String.valueOf(name2));
        t3.setText(String.valueOf(name3));
        t4.setText(String.valueOf(name4));
        t5.setText(String.valueOf(name5));
        t10.setText(String.valueOf(name10));



    }

}
