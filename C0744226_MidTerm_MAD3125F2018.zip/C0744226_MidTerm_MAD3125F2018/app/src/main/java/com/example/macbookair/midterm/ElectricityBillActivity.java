package com.example.macbookair.midterm;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class ElectricityBillActivity extends AppCompatActivity {





    final Context context = this;

    private EditText monthlyUsage;
    private EditText offPeak;
    private EditText midPeak;
    private EditText onPeak;
    private EditText pending;
    private TextView Total;
    private Button Calculate;
    private Button Print;
    double totalMonth;
  //  private EditText totall;
   TextView showTotal;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_electricity_bill);


        monthlyUsage = findViewById(R.id.monthlyUsageID);
        offPeak = findViewById(R.id.offpeakID);
        midPeak = findViewById(R.id.midPeakID);
        onPeak = findViewById(R.id.onpeakID);
        pending = findViewById(R.id.pendingID);
        Total = findViewById(R.id.totalAmountID);
        Calculate = findViewById(R.id.btnCalcID);
        Print = findViewById(R.id.PrintID);
      //  totall = findViewById(R.id.totalAmountID);



        Calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                int mnthInt = Integer.parseInt(monthlyUsage.getText().toString());
                int ofpeakInt = Integer.parseInt(offPeak.getText().toString());
                int midInt = Integer.parseInt(midPeak.getText().toString());
                int onInt = Integer.parseInt(onPeak.getText().toString());
                int pendInt = Integer.parseInt(pending.getText().toString());




                // int totInt = Integer.parseInt(Total.getText().toString());


                if (midInt + ofpeakInt + onInt > 100) {
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                            context);

                    // set title
                    alertDialogBuilder.setTitle("Attention");

                    // set dialog message
                    alertDialogBuilder
                            .setMessage("You Entered Wrong values for Peak percentage ")
                            .setCancelable(true)

                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Intent tosame = new Intent(ElectricityBillActivity.this, ElectricityBillActivity.class);
                                    startActivity(tosame);

                                }
                            })

                            .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                    dialog.cancel();
                                }
                            });

                    // create alert dialog
                    AlertDialog alertDialog = alertDialogBuilder.create();

                    // show it
                    alertDialog.show();

                } else {



                    if (mnthInt < 100)
                    {
                         totalMonth  = (mnthInt) * 0.75;

                    } else if (mnthInt >100 && mnthInt < 150)
                    {
                        totalMonth = ((mnthInt-100) * 1.25);
                    }else if (mnthInt >150 && mnthInt < 200)
                    {
                        totalMonth = ((mnthInt-150) * 1.75);
                    }
                    else if (mnthInt > 450)
                    {
                        totalMonth = ((mnthInt-200)* 2.25);
                    }






                     /* midInt = mnthInt/6;
                      ofpeakInt = mnthInt/4;
                      onInt = mnthInt/8;

                      int offPeakRate = 6;
                      int offPeakTotal = ((ofpeakInt/100)*mnthInt)*offPeakRate;*/

                      /* let offPeakRate=6.5
        let monthlyUsage = Double(txtMonthlyUsage.text!)
        let offPeakPerc=Double(txtOffPeak.text!)
        var offPeakTotal = ((offPeakPerc!/100)*monthlyUsage!)*offPeakRate
        print(offPeakTotal)
        offPeakTotal=round(100*offPeakTotal)/100
        return offPeakTotal
        */

                  //    ofpeakInt = (mnthInt*1)/100;
                    //  onInt = (mnthInt*3)/100;

                    double totalInt = (totalMonth + midInt  + onInt + pendInt + ofpeakInt);
                    Total.setText(String.valueOf(totalInt));

                }
            }
        });


        // print button
        Print.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String mnthString = monthlyUsage.getText().toString();
                String ofpeakString = offPeak.getText().toString();
                String midString = midPeak.getText().toString();
                String onString = onPeak.getText().toString();
                String pendString = pending.getText().toString();
                String Totall = Total.getText().toString();
                showTotal = findViewById(R.id.totalAmountID);
                String message = showTotal.getText().toString();

                if (mnthString.equals("") || ofpeakString.equals("") || midString.equals("") || onString.equals("") || pendString.equals("")) {

                    Toast.makeText(ElectricityBillActivity.this, "all Fields Are Required", Toast.LENGTH_LONG).show();
                } else {
                    Intent toPrint = new Intent(ElectricityBillActivity.this, PrintActivity.class);
                    toPrint.putExtra("imonthUsage", mnthString);
                    toPrint.putExtra("ioffPeak", ofpeakString);
                    toPrint.putExtra("imidPeak", midString);
                    toPrint.putExtra("ionPeak", onString);
                    toPrint.putExtra("ipending", pendString);
                    toPrint.putExtra("showTotal" , message);
                  //  toPrint.putExtra("totall" , Total);
                    startActivity(toPrint);
                    finish();


                }
            }

        });
    }
}
