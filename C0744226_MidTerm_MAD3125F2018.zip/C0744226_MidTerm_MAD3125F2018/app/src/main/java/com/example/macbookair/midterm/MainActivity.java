package com.example.macbookair.midterm;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    final Context context = this;


    private TextView username;
    private TextView password;
    private Button loginBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.userNameID);
        password = findViewById(R.id.passwordID);

        loginBtn = findViewById(R.id.loginbtnID);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String userName = username.getText().toString();
                String passWord = password.getText().toString();

                if (userName.equalsIgnoreCase("admin") && passWord.equals("admin"))
                {
                    Intent mIntent = new Intent(MainActivity.this , ElectricityBillActivity.class);
                    startActivity(mIntent);
                    Toast.makeText(MainActivity.this , "Successfully Logged In" , Toast.LENGTH_LONG).show();
                }
                else
                {
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                            context);

                    // set title
                    alertDialogBuilder.setTitle("Error");

                    // set dialog message
                    alertDialogBuilder
                            .setMessage("You Entered Wrong Username or password")
                            .setCancelable(true)

                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Intent tosame = new Intent(MainActivity.this , MainActivity.class);
                                    startActivity(tosame);

                                }
                            })

                            .setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,int id) {

                                    dialog.cancel();
                                }
                            });

                    // create alert dialog
                    AlertDialog alertDialog = alertDialogBuilder.create();

                    // show it
                    alertDialog.show();

                    //Toast message for invalid input---

                    //Toast.makeText(MainActivity.this , "Enter Valid Username and Password Please" , Toast.LENGTH_LONG).show();

                }



            }
        });


    }
}
